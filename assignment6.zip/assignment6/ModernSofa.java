package kz.aitu.oop.assignment6;

public class ModernSofa implements Sofa{

    @Override
    public void description() {
        System.out.println("This is modern sofa.");
    }

    @Override
    public void showQuality() {
        System.out.println("Modern sofa is new.");
    }
}
