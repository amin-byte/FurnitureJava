package kz.aitu.oop.assignment6;

public interface Sofa {
    public void description();
    public void showQuality();

}
