package kz.aitu.oop.assignment6;

public interface Chair {
    public void description();
    public void hasLegs();
    public void sitOn();
}
