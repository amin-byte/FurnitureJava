package kz.aitu.oop.assignment6;

public interface CoffeeTable {
    public void description();
    public void showMaterial();

}
